/**
 * 
 */
package org.cvtc.ships;

/**
 * @author wlarrabee
 *
 */
public class DestroyerShip extends Ship {
	
	public DestroyerShip(String direction, int startX, int startY) {
		super(3, direction, startX, startY);
	}
}
