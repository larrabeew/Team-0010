/**
 * 
 */
package org.cvtc.ships;

/**
 * @author wlarrabee
 *
 */
public class BattleShip extends Ship {
	
	public BattleShip(String direction, int startX, int startY) {
		super(4, direction, startX, startY);
	}

}