/**
 * 
 */
package org.cvtc.ships;

/**
 * @author wlarrabee
 *
 */
public class SubShip extends Ship {
	
	public SubShip(String direction, int startX, int startY) {
		super(3, direction, startX, startY);
	}

}
