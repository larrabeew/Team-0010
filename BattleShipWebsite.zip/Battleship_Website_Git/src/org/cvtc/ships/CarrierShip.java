/**
 * 
 */
package org.cvtc.ships;

/**
 * @author wlarrabee
 *
 */
public class CarrierShip extends Ship {
	
	public CarrierShip(String direction, int startX, int startY) {
		super(5, direction, startX, startY);
	}

}
