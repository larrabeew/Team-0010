/**
 * 
 */
package org.cvtc.ships;

/**
 * @author wlarrabee
 *
 */
public class PBShip extends Ship {

	public PBShip(String direction, int startX, int startY) {
		super(2, direction, startX, startY);
	}

}
